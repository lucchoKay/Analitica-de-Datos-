import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score, roc_curve, auc, confusion_matrix, ConfusionMatrixDisplay
import matplotlib.pyplot as plt
import numpy as np
import os

df = pd.read_excel("FGR_dataset")

df = df.rename(columns={
    "C1": "Edad",
    "C2": "IMC",
    "C3": "Edad Gestacional (parto)",
    "C4": "Gravidez",
    "C5": "Paridad",
    "C6": "Sintomas inicio",
    "C9": "Edad Gestacional (HTA)",
    "C13": "Edad Gestacional (proteinuria)",
    "C17": "Antecedentes",
    "C18": "Presion sistolica max",
    "C19": "Presion diastolica max",
    "C23": "Creatinina max",
    "C25": "Proteinuria max",
    "C31": "Peso Fetal"
})

features = [
    "Edad", "IMC", "Edad Gestacional (parto)", "Gravidez", "Paridad",
    "Sintomas inicio", "Edad Gestacional (HTA)", "Edad Gestacional (proteinuria)",
    "Antecedentes", "Presion sistolica max", "Presion diastolica max",
    "Creatinina max", "Proteinuria max"
]

df["FGR"] = np.where(df["Peso Fetal"] < 2500, 1, 0)

X = df[features]
y = df["FGR"]

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
joblib.dump(scaler, "models/escalador.pkl")

X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

os.makedirs("models", exist_ok=True)

def evaluar_modelo(modelo, X_test, y_test, nombre):
    y_pred = modelo.predict(X_test)
    acc = accuracy_score(y_test, y_pred)

    modelo_nombre = (
        nombre.lower()
        .replace(' ', '_')
        .replace('(', '')
        .replace(')', '')
        .replace('á', 'a')
        .replace('é', 'e')
        .replace('í', 'i')
        .replace('ó', 'o')
        .replace('ú', 'u')
        .replace('ñ', 'n')
    )

    print(f"{nombre} - Accuracy: {acc:.2f}")

    os.makedirs("models", exist_ok=True)
    os.makedirs("static/graficas", exist_ok=True)

    if acc >= 0.80:
        joblib.dump(modelo, f"models/{modelo_nombre}.pkl")
    else:
        print(f"{nombre} NO alcanzó 80% de precisión, pero se generarán gráficas.")

    if hasattr(modelo, "predict_proba"):
        y_score = modelo.predict_proba(X_test)[:, 1]
    else:
        y_score = y_pred
    fpr, tpr, _ = roc_curve(y_test, y_score)
    roc_auc = auc(fpr, tpr)

    plt.figure()
    plt.plot(fpr, tpr, label=f'{nombre} (AUC = {roc_auc:.2f})')
    plt.plot([0, 1], [0, 1], 'k--')
    plt.title(f'Curva ROC - {nombre}')
    plt.xlabel('Falsos Positivos')
    plt.ylabel('Verdaderos Positivos')
    plt.legend(loc='lower right')
    plt.grid()
    plt.tight_layout()
    plt.savefig(f"static/graficas/roc_{modelo_nombre}.png")
    plt.close()

    cm = confusion_matrix(y_test, y_pred)
    disp = ConfusionMatrixDisplay(confusion_matrix=cm)
    disp.plot(cmap=plt.cm.Blues)
    plt.title(f'Matriz de Confusión - {nombre}')
    plt.grid(False)
    plt.tight_layout()
    plt.savefig(f"static/graficas/cm_{modelo_nombre}.png")
    plt.close()

logistic_model = LogisticRegression(max_iter=3000)
logistic_model.fit(X_train, y_train)
evaluar_modelo(logistic_model, X_test, y_test, "Regresión Logística")

mlp_model = MLPClassifier(hidden_layer_sizes=(100, 50), max_iter=3000)
mlp_model.fit(X_train, y_train)
evaluar_modelo(mlp_model, X_test, y_test, "Red Neuronal (MLP)")

svm_model = SVC(probability=True)
svm_model.fit(X_train, y_train)
evaluar_modelo(svm_model, X_test, y_test, "SVM")

class MapaCognitivoDifuso:
    def predict(self, X):
        return np.where(X[:, 1] > 30, 1, 0)
fcm_model = MapaCognitivoDifuso()
evaluar_modelo(fcm_model, X_test, y_test, "Mapa Cognitivo Difuso")

print("Proceso finalizado.")