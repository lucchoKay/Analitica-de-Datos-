from flask import Flask, render_template, request
import pandas as pd
import joblib
import os
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc, confusion_matrix, ConfusionMatrixDisplay
import uuid

class MapaCognitivoDifuso:
    def predict(self, X):
        X = np.array(X)
        return np.where(X[:, 1] > 30, 1, 0)  # Regla simple como ejemplo

app = Flask(__name__)

modelos = {
    "Regresión logística": joblib.load("models/logistic_model.pkl"),
    "Red neuronal artificial": joblib.load("models/mlp_model.pkl"),
    "Máquina de vector soporte": joblib.load("models/svm_model.pkl"),
    "Mapa cognitivo difuso": joblib.load("models/fcm_model.pkl")
}

columnas = [
    "Edad", "IMC", "Edad Gestacional (parto)", "Gravidez", "Paridad",
    "Sintomas inicio", "Edad Gestacional (HTA)", "Edad Gestacional (proteinuria)",
    "Antecedentes", "Presion sistolica max", "Presion diastolica max",
    "Creatinina max", "Proteinuria max"
]

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/manual', methods=['GET', 'POST'])
def manual_prediction():
    if request.method == 'POST':
        try:
            if 'resultado' in request.form:
                return render_template("manual_prediction.html", datos=request.form)

            datos = [
                float(request.form['Age']),
                float(request.form['BMI']),
                float(request.form['Gestational age of delivery']),
                float(request.form['Gravidity']),
                float(request.form['Parity']),
                int(request.form['Initial onset symptoms']),
                float(request.form['Gestational age of hypertension onset']),
                float(request.form['Gestational age of proteinuria onset']),
                int(request.form['Past history']),
                float(request.form['Maximum systolic blood pressure']),
                float(request.form['Maximum diastolic blood pressure']),
                float(request.form['Maximum values of creatinine']),
                float(request.form['Maximum proteinuria value'])
            ]
            modelo_nombre = request.form['modelo']
            modelo = modelos[modelo_nombre]
            prediccion = modelo.predict([datos])[0]
            return render_template(
                "result.html",
                resultado="Normal" if prediccion == 0 else "FGR",
                modelo=modelo_nombre,
                datos=request.form  # Aquí sí se pasa datos
            )
        except Exception as e:
            return f"Error en los datos: {str(e)}"

    return render_template("manual_prediction.html", datos={})

@app.route('/batch', methods=['GET', 'POST'])
def batch_prediction():
    if request.method == 'POST':
        file = request.files['dataset']
        if not file:
            return "No se subió ningún archivo"
        
        try:
            df = pd.read_excel(file)

            df = df.rename(columns={
                "C1": "Edad",
                "C2": "IMC",
                "C3": "Edad Gestacional (parto)",
                "C4": "Gravidez",
                "C5": "Paridad",
                "C6": "Sintomas inicio",
                "C9": "Edad Gestacional (HTA)",
                "C13": "Edad Gestacional (proteinuria)",
                "C17": "Antecedentes",
                "C18": "Presion sistolica max",
                "C19": "Presion diastolica max",
                "C23": "Creatinina max",
                "C25": "Proteinuria max",
                "C31": "Peso Fetal"
            })

            X = df[columnas]
            y = df["Peso Fetal"]

            modelo_nombre = request.form['modelo']
            modelo = modelos[modelo_nombre]
            y_pred = modelo.predict(X)
            exactitud = (y == y_pred).mean()

            os.makedirs("static/graficas", exist_ok=True)

            fpr, tpr, _ = roc_curve(y, y_pred)
            roc_auc = auc(fpr, tpr)
            roc_filename = f"roc_{uuid.uuid4().hex}.png"
            roc_path = os.path.join("static/graficas", roc_filename)

            plt.figure()
            plt.plot(fpr, tpr, color='blue', label=f'AUC = {roc_auc:.2f}')
            plt.plot([0, 1], [0, 1], color='gray', linestyle='--')
            plt.xlabel('Tasa de Falsos Positivos')
            plt.ylabel('Tasa de Verdaderos Positivos')
            plt.title('Curva ROC')
            plt.legend(loc="lower right")
            plt.savefig(roc_path)
            plt.close()

            cm = confusion_matrix(y, y_pred)
            cm_display = ConfusionMatrixDisplay(cm)
            cm_filename = f"cm_{uuid.uuid4().hex}.png"
            cm_path = os.path.join("static/graficas", cm_filename)

            cm_display.plot(cmap=plt.cm.Blues)
            plt.title("Matriz de Confusión")
            plt.savefig(cm_path)
            plt.close()

            return render_template(
                "result.html",
                resultado=f"Exactitud del modelo: {exactitud:.2%}",
                modelo=modelo_nombre,
                curva_roc=roc_filename,
                matriz_conf=cm_filename,
                datos={}  # Se agrega datos vacío para evitar error
            )

        except Exception as e:
            return f"Error procesando el archivo: {str(e)}"
    
    return render_template("batch_prediction.html")

if __name__ == '__main__':
    app.run(debug=True)
